require 'json'
require 'httparty'

def lambda_handler(event:, context:)
    response = HTTParty.get('https://pub.storypro.io/feed.json')
    entries = JSON.parse(response.body)['entries']

    discussions = []

    entries.each do |entry|
        discussions.push entry if entry['type'] == 'Discussion'

    end

    puts discussions


    { statusCode: 200, body: discussions.to_json }
end

#lambda_handler(event: 'hi', context: 'bye')